from __future__ import annotations
from . import ConnectionBase
from ..utils import value_to_boolean
from ..exceptions import DAGException

from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import ec
from cryptography.hazmat.primitives.serialization import load_der_private_key

try:
    from keeper_secrets_manager_core import utils
    from keeper_secrets_manager_core.configkeys import ConfigKeys
    from keeper_secrets_manager_core.storage import InMemoryKeyValueStorage, KeyValueStorage
    from keeper_secrets_manager_core.utils import url_safe_str_to_bytes, bytes_to_base64, generate_random_bytes
except ImportError:
    raise Exception("Please install the keeper_secrets_manager_core module to use the Ksm connection.")

import logging
import json
import os
import requests

from typing import Union, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from keeper_secrets_manager_core.storage import KeyValueStorage
    from keeper_secrets_manager_core.dto.dtos import Record
    KsmConfig = Union[dict, str, KeyValueStorage]
    Content = Union[str, bytes, dict]
    QueryValue = Union[list, dict, str, float, int, bool]


class Connection(ConnectionBase):

    KEEPER_CLIENT = 'ms16.2.4'

    def __init__(self, config: Union[str, dict, KeyValueStorage], verify_ssl: bool = None):

        super().__init__(is_device=True)

        if InMemoryKeyValueStorage.is_base64(config):
            config = utils.base64_to_string(config)
        if isinstance(config, str) is True:
            config = json.loads(config)

        if isinstance(config, dict) is False and isinstance(config, KeyValueStorage) is False:
            raise DAGException("The configuration is not a dictionary.")

        if verify_ssl is None:
            verify_ssl = value_to_boolean(os.environ.get("VERIFY_SSL", "TRUE"))

        self.config = config
        self.verify_ssl = verify_ssl
        self._signature = None
        self._challenge_str = None

    @staticmethod
    def get_record_uid(record: Record) -> str:
        return record.uid

    @staticmethod
    def get_key_bytes(record: Record) -> bytes:
        return record.record_key_bytes

    def get_config_value(self, key: ConfigKeys) -> str:
        if isinstance(self.config, KeyValueStorage) is True:
            return self.config.get(key)
        else:
            return self.config.get(key.value)

    @property
    def hostname(self) -> str:
        return os.environ.get("ROUTER_HOST", self.get_config_value(ConfigKeys.KEY_HOSTNAME))

    @property
    def client_id(self) -> str:
        return self.get_config_value(ConfigKeys.KEY_CLIENT_ID)

    @property
    def private_key(self) -> str:
        return self.get_config_value(ConfigKeys.KEY_PRIVATE_KEY)

    @property
    def app_key(self) -> str:
        return self.get_config_value(ConfigKeys.KEY_APP_KEY)

    def router_url_from_ksm_config(self) -> str:
        return f'connect.{self.hostname}'

    def ws_router_url_from_ksm_config(self, is_ws: bool = False) -> str:

        router_host = self.router_url_from_ksm_config()
        if router_host.startswith('ws') or router_host.startswith('http'):
            return router_host

        kpam_router_ssl_enabled_env = os.environ.get("USE_SSL", True)

        if is_ws:
            prot_pref = 'ws'
        else:
            prot_pref = 'http'

        if not kpam_router_ssl_enabled_env:
            return f'{prot_pref}://{router_host}'
        else:
            return f'{prot_pref}s://{router_host}'

    def http_router_url_from_ksm_config_or_env(self) -> str:

        router_host_from_env = os.getenv("KROUTER_URL")
        if router_host_from_env:
            router_http_host = router_host_from_env
        else:
            router_http_host = self.ws_router_url_from_ksm_config()

        return router_http_host.replace('ws', 'http')

    def authenticate(self, refresh: bool = False) -> (str, str):

        if self._signature is None or refresh is True:

            logging.debug(f"signature is blank or refresh {refresh}")

            try:
                router_http_host = self.http_router_url_from_ksm_config_or_env()
                response = requests.get(f'{router_http_host}/api/device/get_challenge', verify=self.verify_ssl)
                response.raise_for_status()
            except requests.exceptions.HTTPError as http_err:
                raise SystemExit(http_err)
            except Exception as err:
                raise SystemExit(err)

            self._challenge_str = response.text
            if self._challenge_str is None or self._challenge_str == "":
                raise Exception("Challenge text is blank. Cannot authenticate into the DAG web service.")

            private_key_der_bytes = url_safe_str_to_bytes(self.private_key)
            client_id_bytes = url_safe_str_to_bytes(self.client_id)

            logging.debug('Adding challenge to the signature before connecting to the router')
            challenge_bytes = url_safe_str_to_bytes(self._challenge_str)
            client_id_bytes = client_id_bytes + challenge_bytes

            pk = load_der_private_key(private_key_der_bytes, password=None)
            sig = pk.sign(client_id_bytes, ec.ECDSA(hashes.SHA256()))

            self._signature = bytes_to_base64(sig)

        return self._signature, self._challenge_str

    def rest_call_to_router(self, http_method: str, endpoint: str,
                            payload_json: Optional[Union[bytes, str]] = None,
                            timeout: Optional[int] = None) -> str:

        # If the timeout has not been set, default to 60 seconds.
        if timeout == 0:
            timeout = 60

        router_host = self.http_router_url_from_ksm_config_or_env()
        url = router_host + endpoint

        refresh = False
        while True:
            try:
                signature, challenge_str = self.authenticate(refresh=refresh)
                headers = dict(
                    Signature=signature,
                    ClientVersion=Connection.KEEPER_CLIENT,
                    Authorization=f'KeeperDevice {self.client_id}',
                    Challenge=challenge_str
                )

                logging.debug(f'Connecting to {url} with headers: {headers}')

                response = requests.request(
                    method=http_method,
                    url=url,
                    data=payload_json if payload_json else None,
                    verify=self.verify_ssl,
                    timeout=timeout,
                    headers=headers,
                )

                logging.debug(f"response status: {response.status_code}")

                # If we get a 401 Unauthorized, and we have not yet refreshed,
                #  refresh the signature.
                if response.status_code == 401 and refresh is False:
                    logging.debug("rest call was Unauthorized")
                    refresh = True

                # ok = status_code < 400. If the status code is >= 400, it's an error.
                elif response.ok is False:
                    raise DAGException(f"{response.status_code} - {response.text}")
                else:
                    return response.text

            # Handle errors outside of requests
            except Exception as e:
                raise DAGException(f"Couldn't connect to URL {url}:\n{e}")
