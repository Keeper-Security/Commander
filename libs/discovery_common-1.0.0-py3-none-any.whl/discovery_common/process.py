from __future__ import annotations
import logging
from .constants import PAM_DIRECTORY, PAM_DATABASE, PAM_MACHINE, PAM_USER
from .jobs import Jobs
from .infrastructure import Infrastructure
from .record_link import RecordLink
from .rule import Rules
from .types import (DiscoveryObject, DiscoveryUser, DiscoveryDirectory, DiscoveryMachine, Summary, SummaryItem,
                    DiscoveryDatabase, RecordField, RuleActionEnum, UserAcl, PromptActionEnum, PromptResult,
                    BulkRecordAdd, BulkRecordConvert, BulkProcessResults, DirectoryInfo)
from .utils import value_to_boolean
from keeper_dag import EdgeType
from keeper_dag.crypto import bytes_to_urlsafe_str
import hashlib
import functools
import re
# import uuid
import time
from typing import Any, Callable, List, Optional, TYPE_CHECKING


if TYPE_CHECKING:
    from keeper_dag.vertex import DAGVertex


class QuitException(Exception):
    """
    This exception used when the user wants to stop processing of the results, before the end.
    """
    pass


class NoDiscoveryDataException(Exception):
    """
    This exception is thrown when there is no discovery data.
    This is not an error.
    There is just nothing to do.
    """
    pass


class Process:

    # The record types to process.
    # The order defined the order the user will be presented the new discovery objects.
    # The sort defined how the discovery objects for a record type are sorted and presented.
    # Cloud-based users are presented first, then directories second.
    # We want to prompt about users that may appear on machines before processing the machine.
    mapping = {
        PAM_USER: {"order": 1, "sort": "_sort_name", "item": DiscoveryUser, "key": "user"},
        PAM_DIRECTORY: {"order": 1, "sort": "_sort_name", "item": DiscoveryDirectory, "key": "host_port"},
        PAM_MACHINE: {"order": 2, "sort": "_sort_host", "item": DiscoveryMachine, "key": "host"},
        PAM_DATABASE: {"order": 3, "sort": "_sort_host", "item": DiscoveryDatabase, "key": "host_port"},
    }

    def __init__(self, record: Any, job_id: str, logger: Optional[Any] = None, debug_level: int = 0, **kwargs):
        self.job_id = job_id
        self.record = record

        # Remember what passed in a kwargs
        self.passed_kwargs = kwargs

        self.jobs = Jobs(record=record, logger=logger, debug_level=debug_level, **kwargs)
        self.job = self.jobs.get_job(self.job_id)
        self.infra = Infrastructure(record=record, logger=logger, debug_level=debug_level, **kwargs)
        self.record_link = RecordLink(record=record, logger=logger, debug_level=debug_level, **kwargs)

        if logger is None:
            logger = logging.getLogger()
        self.logger = logger
        self.debug_level = debug_level

    @staticmethod
    def get_key_field(record_type: str) -> str:
        return Process.mapping.get(record_type)["key"]

    @staticmethod
    def make_discovery_object_id(content: DiscoveryObject, parent_vertex: Optional[DAGVertex] = None):

        """
        Make an ID for the discovery object.

        This mimics the KDNRM module's id property methods.
        """

        parent_content = None
        if parent_vertex is not None:
            parent_content = DiscoveryObject.get_discovery_object(parent_vertex)

        if content.record_type == PAM_USER:

            object_id = content.item.user
            if parent_content.record_type == PAM_DIRECTORY:
                domain = parent_content.name
                if object_id.endswith(domain) is False:
                    object_id += f"@{domain}"
            else:
                object_id += parent_content.record_uid

            # TODO - Don't use UUID, use the digest stuff below
            # In discovery, to obscure the username, we make a UUID
            # object_id = str(uuid.uuid5(uuid.NAMESPACE_URL, object_id.lower()))
            object_id = object_id.lower()

            # The machine UID just uses the host

        # Configuration types use their record UID. It's very immutable.
        elif content.record_type.endswith("Configuration") is True:
            object_id = content.record_uid.lower()

        elif content.record_type == PAM_MACHINE:
            object_id = content.item.host

            # Else we are going to use the host and port.
            # Databases and directories will use this.
        else:
            object_id = content.item.host + ":" + str(content.item.port)

        return object_id

    @staticmethod
    def make_vertex_uid(content: DiscoveryObject, parent_vertex: Optional[DAGVertex] = None):
        """
        Make a vertex uid for the vertex from the object content.

        This mimics the KDNRM module's uid property methods.
        """

        uid = content.object_type_value + Process.make_discovery_object_id(content, parent_vertex)
        m = hashlib.sha256()
        m.update(uid.lower().encode())

        return bytes_to_urlsafe_str(m.digest()[:16])

    def get_keys_for_vertex(self, vertex: DAGVertex) -> List[str]:
        """
        For the vertex
        :param vertex:
        :return:
        """

        content = DiscoveryObject.get_discovery_object(vertex)
        key_field = self.get_key_field(content.record_type)
        keys = []
        if key_field == "host_port":
            if content.item.port is not None:
                if content.item.host is not None:
                    keys.append(f"{content.item.host}:{content.item.port}".lower())
                if content.item.ip is not None:
                    keys.append(f"{content.item.ip}:{content.item.port}".lower())
        elif key_field == "host":
            if content.item.host is not None:
                keys.append(content.item.host.lower())
            if content.item.ip is not None:
                keys.append(content.item.ip.lower())
        elif key_field == "user":
            if content.parent_record_uid is not None:
                if content.item.user is not None:
                    keys.append(f"{content.parent_record_uid}:{content.item.user}".lower())
                if content.item.dn is not None:
                    keys.append(f"{content.parent_record_uid}:{content.item.dn}".lower())
        return keys

    @staticmethod
    def _sort_name(vertices: List[DAGVertex]) -> List[DAGVertex]:
        """
        Sort the vertices by name in ascending order.
        """

        def _sort(t1: DAGVertex, t2: DAGVertex):
            t1_name = t1.content_as_dict.get("name")
            t2_name = t2.content_as_dict.get("name")
            if t1_name < t2_name:
                return -1
            elif t1_name > t2_name:
                return 1
            else:
                return 0

        return sorted(vertices, key=functools.cmp_to_key(_sort))

    @staticmethod
    def _sort_host(vertices: List[DAGVertex]) -> List[DAGVertex]:
        """
        Sort the vertices by host name.

        Host name should appear first in ascending order.
        IP should appear second in ascending order.

        """

        def _is_ip(host: str) -> bool:
            if re.match(r'^\d+\.\d+\.\d+\.\d+', host) is not None:
                return True
            return False

        def _make_ip_number(ip: str) -> int:
            ip_port = ip.split(":")
            parts = ip_port[0].split(".")
            value = ""
            for part in parts:
                value += part.zfill(3)
            return int(value)

        def _sort(t1: DAGVertex, t2: DAGVertex):
            t1_name = t1.content_as_dict.get("name")
            t2_name = t2.content_as_dict.get("name")

            # Both names are ip addresses
            if _is_ip(t1_name) and _is_ip(t2_name):
                t1_num = _make_ip_number(t1_name)
                t2_num = _make_ip_number(t2_name)

                if t1_num < t2_num:
                    return -1
                elif t1_num > t2_num:
                    return 1
                else:
                    return 0

            # T1 is an IP, T2 is a host name
            elif _is_ip(t1_name) and not _is_ip(t2_name):
                return 1
            # T2 is not an IP and T2 is an IP
            elif not _is_ip(t1_name) and _is_ip(t2_name):
                return -1
            # T1 and T2 are host name
            else:
                if t1_name < t2_name:
                    return -1
                elif t1_name > t2_name:
                    return 1
                else:
                    return 0

        return sorted(vertices, key=functools.cmp_to_key(_sort))

    def _update_with_record_uid(self, record_cache: dict, current_vertex: DAGVertex):

        # If the current vertex is not active, then return.
        # It won't have a DATA edge.
        if current_vertex.active is False:
            return

        for vertex in current_vertex.has_vertices():

            # Skip if the vertex is not active.
            # It won't have a DATA edge.
            if vertex.active is False:
                continue

            # Don't worry about "item" class type
            content = DiscoveryObject.get_discovery_object(vertex)

            # If we are ignoring the object, then skip.
            if content.action_rules_result == RuleActionEnum.IGNORE.value or content.ignore_object is True:
                continue
            elif content.record_uid is not None:
                cache_keys = self.get_keys_for_vertex(vertex)
                for key in cache_keys:

                    # If we find an item in the cache, update the vertex with the record UID
                    if key in record_cache.get(content.record_type):
                        content.record_uid = record_cache.get(content.record_type).get(key)
                        vertex.add_data(content)
                        break

            # Process the vertices that belong to the current vertex.
            self._update_with_record_uid(
                record_cache=record_cache,
                current_vertex=vertex,
            )

    @staticmethod
    def _prepare_record(record_prepare_func: Callable,
                        bulk_add_records: List[BulkRecordAdd],
                        content: DiscoveryObject,
                        parent_content: DiscoveryObject,
                        vertex: DAGVertex,
                        context: Optional[Any] = None) -> DiscoveryObject:
        """
        Prepare a record to be added.

        :param record_prepare_func:
        :param bulk_add_records:
        :param content:
        :param parent_content:
        :param vertex:
        :param context:
        :return:
        """

        record_to_be_added, record_uid = record_prepare_func(
            content=content,
            context=context
        )

        bulk_add_records.append(
            BulkRecordAdd(
                title=content.title,
                record=record_to_be_added,
                record_type=content.record_type,
                record_uid=record_uid,
                parent_record_uid=parent_content.record_uid,
                shared_folder_uid=content.shared_folder_uid
            )
        )

        content.record_uid = record_uid
        content.parent_record_uid = parent_content.record_uid
        vertex.add_data(content)

        return content

    def _default_acl(self,
                     discovery_vertex: DAGVertex,
                     content: DiscoveryObject,
                     discovery_parent_vertex: DAGVertex) -> UserAcl:
        # Check to see if this user already belongs to another record vertex, or belongs to this one.
        belongs_to = False
        is_admin = False

        if content.record_exists is False:
            belongs_to = True
            parent_content = DiscoveryObject.get_discovery_object(discovery_parent_vertex)
            if parent_content.access_user is not None:
                if parent_content.access_user.user == content.item.user:
                    is_admin = True
        else:
            belongs_to_record_vertex = self.record_link.acl_has_belong_to_vertex(discovery_vertex)
            if belongs_to_record_vertex is None:
                self.logger.debug("  user vertex does not belong to another resource vertex")
                belongs_to = True
            else:
                parent_record_vertex = self.record_link.get_record_uid(discovery_parent_vertex)
                if parent_record_vertex is not None:
                    if belongs_to_record_vertex == parent_record_vertex:
                        self.logger.debug("  user vertex already belongs to the parent resource vertex")
                        belongs_to = True
                else:
                    self.logger.debug("  user vertex does not belong to any other resource vertex")

        return UserAcl(belongs_to=belongs_to, is_admin=is_admin)

    def _record_link_directory_users(self,
                                     directory_vertex: DAGVertex,
                                     directory_content: DiscoveryObject,
                                     directory_info_func: Callable,
                                     context: Optional[Any] = None):

        """
        Link user record to directory when adding a new directory.

        When adding a new directory, there may be other directories for the same domain.
        We need to link existing directory users, of the same domain, to this new directory.

        """

        self.logger.debug(f"resource is directory; connect users to this directory for {directory_vertex.uid}")

        record_link = context.get("record_link")  # type: RecordLink

        # Get the directory user record UIDs from the vault that belong to directories using the same domain.
        directory_info = directory_info_func(
            domain=directory_content.name,
            context=context
        )  # type: DirectoryInfo
        if directory_info is None:
            self.logger.debug("there were no directory record for this domain")
            directory_info = DirectoryInfo()

        user_record_uids = directory_info.directory_user_record_uids

        self.logger.debug(f"found {len(directory_info.directory_user_record_uids)} "
                          f"from {len(directory_info.directory_record_uids)} directories.")

        # Check our current discovery data.
        # This is a delta, it will not contain discovery from prior runs.
        # This will only contain objects in this run.
        # Make sure the object is a directory and the domain is the same.
        # Also make sure there is a record UID; it might not be added yet.
        self.logger.debug("finding directories in discovery vertices")
        for parent_vertex in directory_vertex.belongs_to_vertices():
            self.logger.debug(f"find directories under {parent_vertex.uid}")
            for other_directory_vertex in parent_vertex.has_vertices():
                if other_directory_vertex.uid == directory_vertex.uid:
                    continue
                other_directory_content = DiscoveryObject.get_discovery_object(other_directory_vertex)
                self.logger.debug(f"{other_directory_content.record_type}, {other_directory_content.name}, "
                                  f"{other_directory_content.uid}, {other_directory_content.record_uid}")
                if (other_directory_content.record_type == PAM_DIRECTORY
                        and other_directory_content.name == directory_content.name
                        and other_directory_content.record_uid is not None):
                    self.logger.debug(f"check {other_directory_content.uid} for users")
                    for user_vertex in other_directory_vertex.has_vertices():
                        user_content = DiscoveryObject.get_discovery_object(user_vertex)
                        self.logger.debug(f" * {user_vertex.uid}, {user_content.record_uid}")
                        if user_content.record_uid is not None and user_content.record_uid not in user_record_uids:
                            user_record_uids.append(user_content.record_uid)

        self.logger.debug(f"found {len(user_record_uids)} user to connect to directory")

        # Make sure there is a link from the user record to the directory record.
        # We also might need to make a KEY edge from the user to the directory if one does not exist.
        for record_uid in user_record_uids:
            record_link.belongs_to(record_uid, directory_content.record_uid, acl=UserAcl())

            # Check if the user vertex has a KEY edge to the directory_vertex.
            found_vertices = directory_vertex.dag.search_content({"record_uid": record_uid})
            if len(found_vertices) == 1:
                user_vertex = found_vertices[0]
                if user_vertex.get_edge(directory_vertex, EdgeType.KEY) is None:
                    self.logger.debug(f"adding a KEY edge from the user {user_vertex.uid} to {directory_vertex.uid}")
                    user_vertex.belongs_to(directory_vertex, EdgeType.KEY)
            else:
                self.logger.debug("could not find user vertex")

    def _record_link_user_to_directories(self,
                                         directory_vertex: DAGVertex,
                                         directory_content: DiscoveryObject,
                                         user_content: DiscoveryObject,
                                         directory_info_func: Callable,
                                         context: Optional[Any] = None):

        """
        Connect a user to all the directories for a domain.

        Directories may be in the vault or in the discovery graph.
        The first step is to get all vault directories.

        """

        self.logger.debug("resource is directory and we are a user; handle record links to others")

        record_link = context.get("record_link")  # type: RecordLink

        # Get the directory user record UIDs from the vault that belong to directories using the same domain.
        # We can skip getting directory users.
        directory_record_uids = []
        directory_info = directory_info_func(
            domain=directory_content.name,
            skip_users=True,
            context=context
        )  # type: DirectoryInfo
        if directory_info is not None:
            directory_record_uids = directory_info.directory_record_uids

        self.logger.debug(f"found {len(directory_record_uids)} directories in records.")

        # Check our current discovery data.
        # This is a delta, it will not contain discovery from prior runs.
        # This will only contain objects in this run.
        # Make sure the object is a directory and the domain is the same.
        # Also make sure there is a record UID; it might not be added yet.
        for parent_vertex in directory_vertex.belongs_to_vertices():
            self.logger.debug("finding directories in discovery vertices")
            for child_vertex in parent_vertex.has_vertices():
                other_directory_content = DiscoveryObject.get_discovery_object(child_vertex)
                self.logger.debug(f"{other_directory_content.record_type}, {other_directory_content.name}, "
                                  f"{directory_content.name}, {other_directory_content.record_uid}")
                if (other_directory_content.record_type != PAM_DIRECTORY or
                        other_directory_content.name != directory_content.name):
                    continue
                if (other_directory_content.record_uid is not None and
                        other_directory_content.record_uid not in directory_record_uids):
                    self.logger.debug(f" * adding {other_directory_content.record_uid}")
                    directory_record_uids.append(other_directory_content.record_uid)

        self.logger.debug(f"found {len(directory_record_uids)} directories in records and discovery data.")

        for directory_record_uid in directory_record_uids:
            record_link.belongs_to(user_content.record_uid, directory_record_uid, acl=UserAcl())

    def _process_level(self,
                       current_vertex: DAGVertex,
                       bulk_add_records: List[BulkRecordAdd],
                       bulk_convert_records: List[BulkRecordConvert],
                       prompt_func: Callable,
                       prompt_admin_func: Callable,
                       record_prepare_func: Callable,
                       directory_info_func: Callable,
                       record_cache: dict,
                       indent: int = 0,
                       context: Optional[Any] = None):

        """
        This method will walk the user through discovery delta objects.

        At this point, we only have the delta objects from the graph.
        We do not have the full graph.

        :param current_vertex: The current/parent discovery vertex.
        :param bulk_add_records: List of records to be added.
        :param bulk_convert_records: List of existing records to be covert to this gateway.
        :param prompt_func: Function to call for user prompt.
        :param record_prepare_func: Function to convert content into an unsaved record.
        :param indent: Amount to indent text.
        :param context: Client context; could be anything.
        :return:
        """

        if current_vertex.active is False:
            return

        # Check if this vertex has a record.
        # We cannot add child vertices to a vertex that does not have a record.
        current_content = current_vertex.content_as_object(DiscoveryObject)
        if current_content.record_uid is None:
            self.logger.debug(f"vertex {current_content.uid} does not have a record id")
            return

        self.logger.debug(f"Current Vertex: {current_vertex.uid}, {current_content.name}")

        # Make a map, record type to list of vertices (of that record type)
        record_type_to_vertices_map = {k: [] for k, v in Process.mapping.items()}

        # Collate the vertices into a record type lookup.
        for vertex in current_vertex.has_vertices():
            if vertex.active is False:
                continue
            # We can't load into a pydantic object since Pydantic has a problem with Union type.
            # We only want the record type, so it is too much work to try to get into an object.
            content_dict = vertex.content_as_dict
            record_type = content_dict.get("record_type")
            if record_type in record_type_to_vertices_map:
                record_type_to_vertices_map[record_type].append(vertex)

        # Sort the vertices for each record type.
        for k, v in Process.mapping.items():
            record_type_to_vertices_map[k] = getattr(self, v["sort"])(record_type_to_vertices_map[k])

        # Process the record type by their map order in ascending order.
        for record_type in sorted(record_type_to_vertices_map, key=lambda i: Process.mapping[i]['order']):
            self.logger.debug(f"  processing {record_type}")
            for vertex in record_type_to_vertices_map[record_type]:

                content = DiscoveryObject.get_discovery_object(vertex)

                self.logger.debug(f"    child vertex {vertex.uid}, {content.name}")

                default_acl = None
                if content.record_type == PAM_USER:
                    default_acl = self._default_acl(
                        discovery_vertex=vertex,
                        content=content,
                        discovery_parent_vertex=current_vertex)

                # If we have a record UID, the record exists; we don't need to prompt the user.
                # If a user, we do want to make sure an ACL exists between this user and the resource.
                if content.record_uid is not None:
                    self.logger.debug(f"    record already exists.")

                # If the rule engine result is to ignore this object, then continue.
                # This normally would not happen since discovery wouldn't add the object.
                # However, make sure we skip any object where the rule engine action is to ignore the object.
                elif content.action_rules_result == RuleActionEnum.IGNORE.value:
                    self.logger.debug(f"    vertex {vertex.uid} had a IGNORE result for the rule engine, "
                                      "skip processing")
                    # If the rule engine result is to ignore this object, then continue.
                    continue

                # If this flag is set, the user set the ignore_object flag when prompted.
                elif content.ignore_object is True:
                    self.logger.debug(f"    vertex {vertex.uid} was flagged as ignore, skip processing")
                    # If the ignore_object flag is set, then continue.
                    continue

                # If the rule engine flagged this object to be auto added, and no record exists,
                # prepare a record and add it to the bulk_add_records queue.
                # At the end of processing, the record will be added.
                elif content.action_rules_result == RuleActionEnum.ADD.value and content.record_exists is False:
                    self.logger.debug(f"    vertex {vertex.uid} had an ADD result for the rule engine, auto add")

                    # The record could be a resource or user record.
                    self._prepare_record(
                        record_prepare_func=record_prepare_func,
                        bulk_add_records=bulk_add_records,
                        content=content,
                        parent_content=current_content,
                        vertex=vertex,
                    )

                    self.record_link.discovery_belongs_to(vertex, current_content, acl=default_acl)

                # If the record doesn't exist, then prompt the user.
                elif content.record_exists is False:
                    self.logger.debug(f"    vertex {vertex.uid} had an PROMPT result, prompt user")

                    # For user record, check if the resource record has an admin.
                    # If not, prompt the user if they want to add this user as the admin.
                    # The returned ACL will have the is_admin flag set to True if they do.
                    resource_has_admin = None
                    if content.record_type == PAM_USER:
                        resource_has_admin = (self.record_link.get_admin_record_uid(current_content.record_uid)
                                              is not None)

                    result = prompt_func(
                        vertex=vertex,
                        parent_vertex=current_vertex,
                        content=content,
                        acl=default_acl,
                        resource_has_admin=resource_has_admin,
                        indent=indent,
                        context=context)  # type: PromptResult

                    if result.action == PromptActionEnum.IGNORE:
                        self.logger.debug(f"    vertex {vertex.uid} is being ignored from prompt")
                        result.content.ignore_object = True

                        action_rule_item = Rules.make_action_rule_from_content(
                            content=result.content,
                            action=RuleActionEnum.IGNORE
                        )

                        # Add a rule to ignore this object when doing future discovery.
                        rules = Rules(record=self.record, **self.passed_kwargs)
                        rules.add_rule(action_rule_item)

                        # Even though we are ignoring the object, we will still add it to the infrastructure graph.
                        # This is user selected ignored, not from the rule engine.
                        # vertex.belongs_to(current_vertex, EdgeType.KEY)
                        vertex.add_data(result.content)

                    elif result.action == PromptActionEnum.ADD:
                        self.logger.debug(f"    vertex {vertex.uid} is being added from prompt")

                        # Use the content from the prompt.
                        # The user may have modified it.
                        content = result.content
                        acl = result.acl

                        # The record could be a resource or user record.
                        # The content
                        content = self._prepare_record(
                            record_prepare_func=record_prepare_func,
                            bulk_add_records=bulk_add_records,
                            content=content,
                            parent_content=current_content,
                            vertex=vertex,
                            context=context
                        )

                        # Update the DATA edge for this vertex.
                        vertex.add_data(result.content)

                        # Make a record link.
                        # The acl will be None if not a pamUser.
                        self.record_link.discovery_belongs_to(vertex, current_vertex, acl)

                        # If the object is NOT a pamUser, and there is no admin.
                        # Prompt the user to create an admin.
                        if content.record_type != PAM_USER and prompt_admin_func is not None:
                            self.logger.debug(f"    prompt for admin user")
                            self._process_admin_user(
                                resource_vertex=vertex,
                                resource_content=content,
                                bulk_add_records=bulk_add_records,
                                bulk_convert_records=bulk_convert_records,
                                prompt_admin_func=prompt_admin_func,
                                record_prepare_func=record_prepare_func,
                                indent=indent,
                                context=context
                            )

                        # When a user is added to a directory, check to see if there are other directories with the
                        #  same domain.
                        # This used needs to be added to those directories too.
                        if current_content.record_type == PAM_DIRECTORY and content.record_type == PAM_USER:

                            self._record_link_user_to_directories(
                                directory_vertex=current_vertex,
                                directory_content=current_content,
                                user_content=content,
                                directory_info_func=directory_info_func,
                                context=context
                            )

                        # If the new record is a directory, we may need to attach more users to this record.
                        elif content.record_type == PAM_DIRECTORY:

                            self._record_link_directory_users(
                                directory_vertex=vertex,
                                directory_content=content,
                                directory_info_func=directory_info_func,
                                context=context
                            )

                # Process the vertices that belong to the current vertex.
                self._process_level(
                    current_vertex=vertex,
                    bulk_add_records=bulk_add_records,
                    bulk_convert_records=bulk_convert_records,
                    prompt_func=prompt_func,
                    prompt_admin_func=prompt_admin_func,
                    record_prepare_func=record_prepare_func,
                    directory_info_func=directory_info_func,
                    record_cache=record_cache,
                    indent=indent + 1,
                    context=context
                )
            self.logger.debug(f"  finished processing {record_type}")
        self.logger.debug(f"  Finished current Vertex: {current_vertex.uid}, {current_content.name}")

    def _process_admin_user(self,
                            resource_vertex: DAGVertex,
                            resource_content: DiscoveryObject,
                            bulk_add_records: List[BulkRecordAdd],
                            bulk_convert_records: List[BulkRecordConvert],
                            prompt_admin_func: Callable,
                            record_prepare_func: Callable,
                            indent: int = 0,
                            context: Optional[Any] = None):

        # Find the record UID that admins this resource.
        # If it is None, there is a user vertex that has an ACL with is_admin with a true value.
        record_uid = self.record_link.get_record_uid(resource_vertex)
        admin = self.record_link.get_admin_record_uid(record_uid)
        if admin is None:

            # If the access_user is None, create an empty one.
            # We will need this below when adding values to the fields.
            if resource_content.access_user is None:
                resource_content.access_user = DiscoveryUser()

            # Initialize a discovery object for the admin user.
            # The PLACEHOLDER will be replaced after the admin user prompt.
            admin_content = DiscoveryObject(
                uid="PLACEHOLDER",
                object_type_value="users",
                parent_record_uid=resource_content.record_uid,
                record_type=PAM_USER,
                id="PLACEHOLDER",
                name="PLACEHOLDER",
                description=resource_content.description + ", Administrator",
                title=resource_content.title + ", Administrator",
                last_seen=int(time.time()),
                not_seen_count=0,
                item=DiscoveryUser(
                    user="PLACEHOLDER"
                ),
                fields=[
                    RecordField(type="login", label="login", value=[resource_content.access_user.user],
                                required=True),
                    RecordField(type="password", label="password",
                                value=[resource_content.access_user.password], required=False),
                    RecordField(type="secret", label="privatePEMKey",
                                value=[resource_content.access_user.private_key], required=False),
                    RecordField(type="text", label="distinguishedName",
                                value=[resource_content.access_user.dn], required=False),
                    RecordField(type="text", label="connectDatabase",
                                value=[resource_content.access_user.database], required=False),
                    RecordField(type="checkbox", label="managed",
                                value=[resource_content.access_user.managed], required=False),
                ]
            )

            # Prompt to add an admin user to this resource.
            # We are not passing an ACL instance.
            # We'll make it based on if the user is adding a new record or linking to an existing record.
            admin_result = prompt_admin_func(
                parent_vertex=resource_vertex,
                content=admin_content,
                acl=None,
                indent=indent,
                context=context
            )

            # If the action is to ADD, replace the PLACEHOLDER data.
            if admin_result.action == PromptActionEnum.ADD:
                source = "local"
                if resource_content.record_type == PAM_DIRECTORY:
                    source = resource_content.name

                admin_record_uid = admin_result.record_uid

                # We know the ACL is for the admin, so set that to True.
                admin_acl = UserAcl(is_admin=True)

                if admin_record_uid is None:
                    logging.debug("add admin user from content")
                    admin_content = admin_result.content

                    # With the result, we can fill in information in the object item.
                    admin_content.item.user = admin_content.get_field_value("login")
                    admin_content.item.password = admin_content.get_field_value("password")
                    admin_content.item.private_key = admin_content.get_field_value("privatePEMKey")
                    admin_content.item.dn = admin_content.get_field_value("distinguishedName")
                    admin_content.item.database = admin_content.get_field_value("connectDatabase")
                    admin_content.item.managed = value_to_boolean(
                        admin_content.get_field_value("managed")) or False
                    admin_content.item.source = source
                    admin_content.name = admin_content.item.user

                    if admin_content.name is not None:
                        admin_content.description = (resource_content.description + ", User " +
                                                     admin_content.name)

                    admin_content.id = Process.make_discovery_object_id(admin_content, resource_vertex)
                    admin_content.uid = Process.make_vertex_uid(admin_content, resource_vertex)

                    # Does a vertex already exist for this user?
                    # If it does, get its record UID
                    admin_vertex = self.infra.dag.get_vertex(admin_content.uid)
                    if admin_vertex is not None:
                        found_content = DiscoveryObject.get_discovery_object(admin_vertex)
                        admin_record_uid = found_content.record_uid

                    # If there is a record UID for the admin user, connect it
                    if admin_record_uid is not None:

                        # If the admin record does not belong to another resource, make this resource its owner.
                        if self.record_link.get_parent_record_uid(admin_record_uid) is None:
                            admin_acl.belongs_to = True

                        admin_vertex.belongs_to(resource_vertex, edge_type=EdgeType.KEY)
                        self.record_link.belongs_to(admin_record_uid, resource_content.record_uid, acl=admin_acl)
                    else:
                        admin_vertex = self.infra.dag.add_vertex(uid=admin_content.uid,
                                                                 name=admin_content.description)

                        # Since this record does not exist, it will belong to the resource,
                        admin_acl.belongs_to = True

                        # Connect the user vertex to the resource vertex.
                        # We need to add a KEY edge for the admin content stored on the DATA edge.
                        admin_vertex.belongs_to(resource_vertex, edge_type=EdgeType.KEY)
                        admin_vertex.add_data(admin_content)

                        # The record will be a user record; admin_acl will not be None
                        self._prepare_record(
                            record_prepare_func=record_prepare_func,
                            bulk_add_records=bulk_add_records,
                            content=admin_content,
                            parent_content=resource_content,
                            vertex=admin_vertex,
                            context=context
                        )

                        self.record_link.discovery_belongs_to(admin_vertex, resource_vertex, acl=admin_acl)

                else:
                    logging.debug("add admin user from existing record")

                    # This is a pamUser record that may need to have the controller set.
                    # Add it to this queue to make sure the protobuf items are current.
                    bulk_convert_records.append(
                        BulkRecordConvert(
                            record_uid=admin_record_uid,
                            parent_record_uid=resource_content.record_uid,
                        )
                    )

                    # If this user record does not belong to another resource, make it belong to this one.
                    record_vertex = self.record_link.acl_has_belong_to_record_uid(admin_record_uid)
                    if record_vertex is None:
                        admin_acl.belongs_to = True

                    # There is _prepare_record, the record exists.
                    # Needs to add to records linking.

                    # Link the record UIDs.
                    # We might not have this user in discovery data.
                    # It might not belong to the resource; if so, it cannot be rotated.
                    # It only has is_admin in the ACL.
                    self.record_link.belongs_to(
                        admin_record_uid,
                        record_uid,
                        acl=admin_acl
                    )

    def _summary_level(self, current_vertex: DAGVertex, summary: Summary):

        # Check if this vertex has a record.
        # We cannot add child vertices to a vertex that does not have a record.
        current_content = DiscoveryObject.model_validate_json(current_vertex.content_as_str)
        if current_content.record_uid is None:
            return

        for vertex in current_vertex.has_vertices():

            # Don't worry about "item" class type
            content = vertex.content_as_object(DiscoveryObject)

            # If the rule engine result is to ignore this object, then continue.
            if content.action_rules_result == RuleActionEnum.IGNORE.value:
                summary.ignored.append(
                    SummaryItem(
                        vertex_uid=vertex.uid,
                        record_type=content.record_type
                    )
                )
                continue

                # If the rule engine result is to ignore this object, then continue.
            elif content.action_rules_result == RuleActionEnum.ADD.value:
                summary.auto_add.append(
                    SummaryItem(
                        vertex_uid=vertex.uid,
                        record_type=content.record_type
                    )
                )
            elif content.record_uid is not None:
                summary.prompt.append(
                    SummaryItem(
                        vertex_uid=vertex.uid,
                        record_type=content.record_type
                    )
                )

            # Process the vertices that belong to the current vertex.
            self._summary_level(
                current_vertex=vertex,
                summary=summary
            )

    def summary(self) -> Summary:
        sync_point = self.job.delta.sync_point
        if sync_point is None:
            raise Exception("The job does not have a sync point for the graph.")

        # Get the root vertex, which has nothing we care about.
        # But from the root, get the configuration vertex.
        # There will be only one.
        self.logger.debug(f"loading the graph at sync point {sync_point}")
        self.infra.load(sync_point=sync_point)
        root = self.infra.get_root
        configuration = root.has_vertices()[0]

        summary = Summary()
        self._summary_level(configuration, summary)

        return summary

    def run(self,
            prompt_func: Callable,
            record_prepare_func: Callable,
            record_create_func: Optional[Callable] = None,
            record_convert_func: Optional[Callable] = None,
            prompt_confirm_add_func: Optional[Callable] = None,
            prompt_admin_func: Optional[Callable] = None,
            directory_info_func: Optional[Callable] = None,
            context: Optional[Any] = None,
            record_cache: Optional[dict] = None
            ) -> BulkProcessResults:
        """
        Process the discovery results.

        :param record_cache: A dictionary of record types to keys to record UID.
        :param prompt_func: Function to call when the user needs to make a decision about an object.
        :param record_prepare_func: Function to call to prepare a record to be created.
        :param record_create_func: Function to call to save the prepared records.
        :param record_convert_func: Function to convert record to use this gateway.
        :param prompt_confirm_add_func: Function to call if quiting and record have been added to queue.
        :param prompt_admin_func: Function to prompt user for admin.
        :param directory_info_func: Function to get users of a dirctory from vault records.
        :param context: Context passed to the prompt and add function. These could be objects that are not in the scope
                        of the function.
        :return:
        """
        sync_point = self.job.sync_point
        if sync_point is None:
            raise Exception("The job does not have a sync point for the graph.")

        # Get the root vertex, which has nothing we care about.
        # But from the root, get the configuration vertex.
        # There will be only one.
        self.logger.debug(f"loading the graph at sync point {sync_point}")
        self.infra.load(sync_point=sync_point)
        if self.infra.has_discovery_data is False:
            raise NoDiscoveryDataException("There is no discovery data to process.")

        root = self.infra.get_root
        configuration = root.has_vertices()[0]

        # If we have a record cache, attempt to find record UID for vertices without record UID.
        if record_cache is not None:
            self._update_with_record_uid(
                record_cache=record_cache,
                current_vertex=configuration,
            )

        # Store records that to be created and record where their protobuf settings need to be updated.
        bulk_add_records = []  # type: List[BulkRecordAdd]
        bulk_convert_records = []  # type: List[BulkRecordConvert]

        should_add_records = True
        bulk_process_results = None

        # Pass an empty
        if context is None:
            context = {}

        # We need record linking and infra graphs in the context.
        # We are adding admin users to check existing admin relationships and to see if AD user.
        context["record_link"] = self.record_link
        context["infra"] = self.infra

        try:
            self._process_level(
                current_vertex=configuration,
                bulk_add_records=bulk_add_records,
                bulk_convert_records=bulk_convert_records,
                prompt_func=prompt_func,
                prompt_admin_func=prompt_admin_func,
                record_prepare_func=record_prepare_func,
                directory_info_func=directory_info_func,
                record_cache=record_cache,
                indent=0,
                context=context)
        except QuitException:
            should_add_records = False

            # If we have record ready to be created, and the confirm prompt function was set, ask the user if they want
            # to add the records.
            if (len(bulk_add_records) > 0 and prompt_confirm_add_func is not None and
                    prompt_confirm_add_func(bulk_add_records) is True):
                should_add_records = True

            modified_count = len(self.infra.dag.modified_edges)
            self.logger.debug(f"quiting and there are {modified_count} modified edges.")

        # We should add the record, and a method was passed in to create them; then add the records.
        if should_add_records is True and record_create_func is not None:
            # Save new records.
            bulk_process_results = record_create_func(
                bulk_add_records=bulk_add_records,
                context=context
            )
            # Update existing record to use this gateway.
            record_convert_func(
                bulk_convert_records=bulk_convert_records,
                context=context
            )

        # Disable delta save.
        self.logger.debug(f"saving additions from process run")
        self.infra.save(delta_graph=False)

        # Save the record linking.
        # This will be the additions and any changes to ACL.
        self.logger.debug(f"save additions from record linking ")
        self.record_link.save()

        return bulk_process_results
