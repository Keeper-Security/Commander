from __future__ import annotations
from tests import setup_logging, get_connection
import os
import unittest
from discovery_common.user_service import UserService
from discovery_common.verify import Verify
from discovery_common.constants import DIS_INFRA_GRAPH_ID
from discovery_common.types import (DiscoveryObject, DiscoveryConfiguration, DiscoveryMachine, DiscoveryUser, Facts,
                                    FactsNameUser)
from keeper_dag.dag import DAG, EdgeType
from keeper_dag.crypto import generate_uid_str
from keeper_secrets_manager_core import mock
from keeper_secrets_manager_core.dto.dtos import Record
import tempfile


class ProcessTest(unittest.TestCase):

    def setUp(self):
        self.logger = setup_logging()
        os.environ["USE_LOCAL_DAG"] = "TRUE"

    def tearDown(self):
        os.environ.pop("USE_LOCAL_DAG", None)

    def test_local_user_service(self):

        with tempfile.TemporaryDirectory() as tmpdir:
            os.environ["LOCAL_DAG_DIR"] = tmpdir

            config_uid = generate_uid_str()
            secret = os.urandom(32)

            provider_mock_record = mock.Record(record_type="pamNetworkConfiguration", title="Fake Network")
            provider_mock_record.field("text", label="pamnetworkid", value="MyNetwork")

            mock_provider_data = provider_mock_record.dump(secret)
            record = Record(mock_provider_data, secret)
            record.uid = config_uid

            # #########################################################################################################
            # INFRASTRUCTURE

            conn = get_connection(tmpdir=tmpdir)
            infra_dag = DAG(conn=conn, record=record, graph_id=DIS_INFRA_GRAPH_ID)

            config_object = DiscoveryObject(
                uid="",
                id="",
                object_type_value="providers",
                record_uid=config_uid,
                record_type="pamNetworkConfiguration",
                fields=[],
                name="CONFIGURATION",
                title="TITLE CONFIGURATION",
                description="DESC CONFIGURATION",
                item=DiscoveryConfiguration(
                    type="pamNetworkConfiguration",
                    info={}
                )
            )

            configuration_vertex = infra_dag.add_vertex(name="configuration")
            configuration_vertex.belongs_to_root(edge_type=EdgeType.KEY)
            configuration_vertex.add_data(config_object)

            machine_object = DiscoveryObject(
                uid="",
                id="",
                object_type_value="machines",
                record_uid=generate_uid_str(),
                record_type="pamMachine",
                fields=[],
                name="MACHINE",
                title="TITLE MACHINE",
                description="DESC MACHINE",
                item=DiscoveryMachine(
                    host="machine.unit.test",
                    ip="192.168.1.1",
                    facts=Facts(
                        name="machine",
                        services=[
                            FactsNameUser(name="Service 1", user='user1'),
                            FactsNameUser(name="Service 2", user='user3'),
                        ],
                        tasks=[
                            FactsNameUser(name="Task 1", user='user2'),
                            FactsNameUser(name="Task 2", user='user3'),
                        ]
                    )
                )
            )

            machine_vertex = infra_dag.add_vertex(name="machine")
            machine_vertex.belongs_to(configuration_vertex, edge_type=EdgeType.KEY)
            machine_vertex.add_data(machine_object)

            user_1_object = DiscoveryObject(
                uid="",
                id="",
                object_type_value="users",
                record_uid=generate_uid_str(),
                record_type="pamUser",
                fields=[],
                name="User1",
                title="TITLE User1",
                description="DESC User1",
                item=DiscoveryUser(
                    user="user1",
                    source="local"
                )
            )

            user_1_vertex = infra_dag.add_vertex(name="user_1")
            user_1_vertex.belongs_to(machine_vertex, edge_type=EdgeType.KEY)
            user_1_vertex.add_data(user_1_object)

            user_2_object = DiscoveryObject(
                uid="",
                id="",
                object_type_value="users",
                record_uid=generate_uid_str(),
                record_type="pamUser",
                fields=[],
                name="User 2",
                title="TITLE User2",
                description="DESC User2",
                item=DiscoveryUser(
                    user="user2",
                    source="local"
                )
            )

            user_2_vertex = infra_dag.add_vertex(name="user_2")
            user_2_vertex.belongs_to(machine_vertex, edge_type=EdgeType.KEY)
            user_2_vertex.add_data(user_2_object)

            user_3_object = DiscoveryObject(
                uid="",
                id="",
                object_type_value="users",
                record_uid=generate_uid_str(),
                record_type="pamUser",
                fields=[],
                name="User3",
                title="TITLE User3",
                description="DESC User3",
                item=DiscoveryUser(
                    user="user3",
                    source="local"
                )
            )

            user_3_vertex = infra_dag.add_vertex(name="user_3")
            user_3_vertex.belongs_to(machine_vertex, edge_type=EdgeType.KEY)
            user_3_vertex.add_data(user_3_object)

            infra_dag.save()

            print(infra_dag.to_dot())

            print("Configuration UID", config_object.record_uid)
            print("Machine UID", machine_object.record_uid)
            print("User 1 UID", user_1_object.record_uid)
            print("User 2 UID", user_2_object.record_uid)
            print("User 3 UID", user_3_object.record_uid)

            verify = Verify(record=record, logger=self.logger, debug_level=1)
            verify.verify_user_service(fix=True)

            user_service = UserService(record=record)
            print(user_service.to_dot())

            log = verify.get_log_per_category(Verify.USER_SERVICE)
            for item in log:
                if item.is_fix is False:
                    print("BAD:", item.msg)
                else:
                    print("FIX:", item.msg)


if __name__ == '__main__':
    unittest.main()
