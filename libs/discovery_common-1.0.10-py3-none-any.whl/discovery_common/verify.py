from __future__ import annotations
import logging
from .infrastructure import Infrastructure
from .record_link import RecordLink
from .user_service import UserService
from .constants import PAM_MACHINE, PAM_DIRECTORY
from .utils import get_connection
from .types import UserAcl, DiscoveryObject, VerifyLogItem
from keeper_dag import DAG, EdgeType
import re
from typing import Any, Optional, List, TYPE_CHECKING

if TYPE_CHECKING:
    from keeper_dag.vertex import DAGVertex


class Verify:

    USER_SERVICE = "User Service/Task Mapping"

    def __init__(self, record: Any, logger: Optional[Any] = None, debug_level: int = 0, **kwargs):

        self.conn = get_connection(**kwargs)

        self.record = record

        # Load all the Infrastructure graph, starting at sync point 0
        self.infra = Infrastructure(record=record, logger=logger, debug_level=debug_level, fail_on_corrupt=False,
                                    **kwargs)
        self.infra.load(sync_point=0)

        self.record_link = RecordLink(record=record, logger=logger, debug_level=debug_level, fail_on_corrupt=False,
                                      **kwargs)
        self.user_service = UserService(record=record, logger=logger, debug_level=debug_level, fail_on_corrupt=False,
                                        **kwargs)

        if logger is None:
            logger = logging.getLogger()
        self.logger = logger
        self.debug_level = debug_level
        self.logger.debug(f"configuration uid is {self.conn.get_record_uid(record)}")

        self.log = {}

    def _log(self, category: str, msg: str, level: int = 1, is_fix: bool = False):
        if category not in self.log:
            self.log[category] = []
        self.log[category].append(VerifyLogItem(msg=msg, level=level, is_fix=is_fix))

        self.logger.debug(f"{category}: {msg}, is_fix: {is_fix}, level: {level}")

    def clear_log(self):
        self.log = {}

    def get_log_per_category(self, category: str):
        return self.log.get(category, [])

    def run(self, fix: bool = False):

        self.clear_log()
        self.verify_user_service(fix=fix)

    @staticmethod
    def _split_user(user: str, hostname: Optional[str] = None, host: Optional[str] = None):
        domain = None
        if "\\" in user:
            domain, user = user.split("\\", 1)
            if domain == ".":
                domain = None
        elif "@" in user:
            user, domain = user.split("@", 1)
        if domain is not None and hostname is not None:
            domain = domain.lower()

            # Don't use IP addresses
            if re.match(r'\d+\.\d+.\d+\.\d+', host) is not None:
                host = None

            if hostname is not None:
                hostname = hostname.lower()
                if domain == hostname:
                    domain = None
                elif domain == hostname.split(".")[0]:
                    domain = None

            if host is not None:
                host = host.lower()
                if domain == host:
                    domain = None
                elif domain == host.split(".")[0]:
                    domain = None

        return user, domain

    def _find_infra_user_vertex(self, resource_vertex: DAGVertex, user: str, domain: Optional[str] = None) -> (
            Optional)[DAGVertex]:

        user = user.lower()
        resource_content = DiscoveryObject.get_discovery_object(resource_vertex)

        # If the domain is None, assume it a local user.
        if domain is None:
            self.logger.debug("    no domain, assume local user")
            for user_vertex in resource_vertex.has_vertices():
                content = DiscoveryObject.get_discovery_object(user_vertex)
                self.logger.debug(f"    * {content.name}, {content.item.user}")
                if content.name.lower() == user:
                    self.logger.debug("        MATCH")
                    return user_vertex
                hostname = None
                if resource_content.record_type == PAM_MACHINE:
                    hostname = resource_content.item.facts.name
                child_user, child_domain = self._split_user(
                    user=content.item.user,
                    hostname=hostname,
                    host=resource_content.item.host)
                if user == child_user and child_domain is None:
                    self.logger.debug("        MATCH")
                    return user_vertex
            return None

        self.logger.debug("    has domain, assume directory user")

        configuration_vertex = self.infra.get_configuration
        for vertex in configuration_vertex.has_vertices():
            content = DiscoveryObject.get_discovery_object(vertex)
            if content.record_type != PAM_DIRECTORY:
                continue
            if content.name.lower() == domain.lower():
                for user_vertex in vertex.has_vertices():
                    user_content = DiscoveryObject.get_discovery_object(user_vertex)
                    if user_content.name.lower() == user or user_content.item.user.lower() == user:
                        return user_vertex

        return None

    def _fix_user_service_acl(self, resource_content: DiscoveryObject, user_vertex: DAGVertex, acl_type: str,
                                fix: bool = False) -> bool:

        user_content = DiscoveryObject.get_discovery_object(user_vertex)
        user_record_uid = user_content.record_uid
        if user_record_uid is not None:
            acl = self.user_service.get_acl(resource_content.record_uid, user_record_uid)
            if acl is not None:
                flag = getattr(acl, acl_type)
                if flag is False:
                    self._log(Verify.USER_SERVICE, f"User {user_content.name}, {user_record_uid} is "
                                                        f"missing an ACL type {acl_type} to "
                                                        f"machine {resource_content.name}")
                    if fix is True:
                        self._log(Verify.USER_SERVICE, f"Added {acl_type} to the ACL between "
                                                       f"user {user_content.name}, {user_record_uid} and "
                                                       f"machine {resource_content.name}", is_fix=True)
                        setattr(acl, acl_type, True)
                        self.user_service.belongs_to(resource_content.record_uid, user_record_uid, acl=acl)
                        return True
                else:
                    self.logger.debug(f"user service ACL does have is_service as True")
            else:
                self.logger.debug(f"there is no ACL between the user and the resource")
        else:
            self.logger.debug(f"use does not have a record yet")

        return False

    def verify_user_service(self, fix: bool = False):

        """

        """

        # STEP 1 - Make sure UserService graph matches Infrastructure

        were_fixes = False

        # Check to make sure the user service graph exists.
        # The "UserService" instance should do this, but we want to make sure.
        if self.user_service.dag.has_graph is False:
            self.logger.debug("the user service graph contains no data")
            configuration_vertex = self.user_service.dag.get_root
            if configuration_vertex.uid != self.record.uid:
                raise Exception("The user service graph root/con does not match ")

        infra_configuration = self.infra.get_configuration
        for resource_vertex in infra_configuration.has_vertices():

            resource_content = DiscoveryObject.get_discovery_object(resource_vertex)

            if resource_content.record_type != PAM_MACHINE or resource_content.record_uid is None:
                self._log(Verify.USER_SERVICE, f"Machine {resource_content.name} does not have record uid",
                          level=0)
                self.logger.debug(f"machine {resource_content.name} does not have record uid, yet.")
                continue

            user_service_resource_vertex = self.user_service.dag.get_vertex(resource_content.record_uid)
            if user_service_resource_vertex is None:
                self.logger.debug(f"machine {resource_content.name} does not have a vertex in the user service graph")
                self._log(Verify.USER_SERVICE, f"Machine {resource_content.name} does not have a vertex in the "
                                               "user service graph.")
                if fix is True:
                    user_service_resource_vertex = self.user_service.dag.add_vertex(resource_content.record_uid)
                    self.user_service.belongs_to(self.record.uid, resource_content.record_uid, acl=None)
                    self._log(Verify.USER_SERVICE, f"Added vertex for machine {resource_content.name}, and linked "
                                                   " to configuration.", is_fix=True)
                else:
                    self.logger.debug(f"  not fixing, skip this resource")
                    continue

            if self.user_service.resource_has_link(resource_content.record_uid) is False:
                self._log(Verify.USER_SERVICE, f"Machine {resource_content.name} is not linked to the "
                                               "configuration")
                if fix is True:
                    user_service_resource_vertex.belongs_to(self.user_service.dag.get_root, edge_type=EdgeType.LINK)
                    self._log(Verify.USER_SERVICE, f"Linking machine {resource_content.name} to the configuration",
                              is_fix=True)
                else:
                    self.logger.debug(f"not fixing, skip this resource")
                    continue

            self.logger.debug(f"found machine: {resource_content.name}, {resource_content.record_uid}")

            for item in resource_content.item.facts.services:
                user, domain = self._split_user(item.user,
                                                hostname=resource_content.item.facts.name, host=resource_content.item.host)
                self.logger.debug(f"found service: {item.name}, {user}, {domain}")
                user_vertex = self._find_infra_user_vertex(resource_vertex, user, domain)
                if user_vertex is not None:
                    if self._fix_user_service_acl(resource_content, user_vertex, "is_service", fix=fix) is True:
                        were_fixes = True
                else:
                    self.logger.debug(f"could not find user for the service on the machine")

            for item in resource_content.item.facts.tasks:
                user, domain = self._split_user(item.user,
                                                hostname=resource_content.item.facts.name, host=resource_content.item.host)
                self.logger.debug(f"  found task: {item.name}, {user}, {domain}")
                user_vertex = self._find_infra_user_vertex(resource_vertex, user, domain)
                if user_vertex is not None:
                    if self._fix_user_service_acl(resource_content, user_vertex, "is_task", fix=fix) is True:
                        were_fixes = True
                else:
                    self.logger.debug(f"    could not find user for the service on the machine")

        if were_fixes is True:
            self.user_service.save()

