import os

def value_to_boolean(value):
    value = str(value)
    if value.lower() in ['true', 'yes', 'on', '1']:
        return True
    elif value.lower() in ['false', 'no', 'off', '0']:
        return False
    else:
        return None


def get_connection(**kwargs):

    if value_to_boolean(os.environ.get("USE_LOCAL_DAG")) is True:
        from keeper_dag.connection.local import Connection
        conn = Connection()
    else:
        ksm = kwargs.get("ksm")
        params = kwargs.get("params")
        if ksm is not None:
            from keeper_dag.connection.ksm import Connection
            conn = Connection(config=ksm.storage_config)
        elif params is not None:
            from keeper_dag.connection.commander import Connection
            conn = Connection(params=params)
        else:
            raise ValueError("Must pass 'ksm' for KSK, 'params' for Commander. Found neither.")
    return conn
