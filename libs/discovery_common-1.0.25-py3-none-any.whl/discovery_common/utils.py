from __future__ import annotations
import os
from typing import List, Optional


def value_to_boolean(value):
    value = str(value)
    if value.lower() in ['true', 'yes', 'on', '1']:
        return True
    elif value.lower() in ['false', 'no', 'off', '0']:
        return False
    else:
        return None


def get_connection(**kwargs):

    """
    This method will return the proper connection based on the params passed in.

    If `ksm` and a KDNRM KSM instance, it will connect using keeper secret manager.
    If `params` and a KeeperParam instance, it will connect using Commander.
    If the env var `USE_LOCAL_DAG` is True, it will connect using the Local test DAG engine.

    It returns a child instance of the Connection class.
    """

    if value_to_boolean(os.environ.get("USE_LOCAL_DAG")) is True:
        from keeper_dag.connection.local import Connection
        conn = Connection()
    else:
        ksm = kwargs.get("ksm")
        params = kwargs.get("params")
        if ksm is not None:
            from keeper_dag.connection.ksm import Connection
            conn = Connection(config=ksm.storage_config)
        elif params is not None:
            from keeper_dag.connection.commander import Connection
            conn = Connection(params=params)
        else:
            raise ValueError("Must pass 'ksm' for KSK, 'params' for Commander. Found neither.")
    return conn


def split_user_and_domain(user: str) -> (Optional[str], Optional[str]):

    if user is None:
        return None, None

    domain = None

    if "\\" in user:
        user_parts = user.split("\\", maxsplit=1)
        user = user_parts[0]
        domain = user_parts[1]
    elif "@" in user:
        user_parts = user.split("@")
        domain = user_parts.pop()
        user = "@".join(user_parts)

    return user, domain


def user_check_list(user: str, name: Optional[str] = None, source: Optional[str] = None) -> List[str]:
    user, domain = split_user_and_domain(user)
    user = user.lower()
    check_list = [user, f".\\{user}", ]
    if name is not None:
        name = name.lower()
        check_list += [name, f".\\{name}"]
    if source is not None:
        check_list.append(f"{source.lower()}\\{user}")
        domain_parts = source.split(".")
        if len(domain_parts) > 1:
            check_list.append(f"{domain_parts[0]}\\{user}")
    if domain is not None:
        domain = domain.lower()
        check_list.append(f"{domain}\\{user}")
        domain_parts = domain.split(".")
        if len(domain_parts) > 1:
            check_list.append(f"{domain_parts[0]}\\{user}")

    return check_list


def user_in_lookup(user: str, lookup: dict, name: Optional[str] = None, source: Optional[str] = None) -> bool:

    for check_user in user_check_list(user, name, source):
        if check_user in lookup:
            return True
    return False

