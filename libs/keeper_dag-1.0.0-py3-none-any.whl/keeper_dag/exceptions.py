class DAGException(Exception):
    pass


class DAGKeyIsEncryptedException(DAGException):
    pass


class DAGDataEdgeNotFoundException(DAGException):
    pass


class DAGDeletionException(DAGException):
    pass


class DAGConfirmException(DAGException):
    pass


class DAGPathException(DAGException):
    pass


class DAGVertexAlreadyExistsException(DAGException):
    pass


class DAGContentException(DAGException):
    pass


class DAGDefaultGraphException(DAGException):
    pass


class DAGIllegalEdgeException(DAGException):
    pass


class DAGKeyException(DAGException):
    pass


class DAGVertexException(DAGException):
    pass


class DAGEdgeException(DAGException):
    pass
