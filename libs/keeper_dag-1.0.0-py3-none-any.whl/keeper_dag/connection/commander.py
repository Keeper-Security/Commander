from __future__ import annotations
from . import ConnectionBase
from ..crypto import bytes_to_base64
import os
import requests

try:
    from keepercommander import crypto, utils, rest_api
except ImportError:
    raise Exception("Please install the keepercommander module to use the Commander connection.")

from typing import Optional, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from keepercommander.params import KeeperParams
    from keepercommander.vault import KeeperRecord
    Content = Union[str, bytes, dict]
    QueryValue = Union[list, dict, str, float, int, bool]


class Connection(ConnectionBase):

    def __init__(self, params: KeeperParams, verify_ssl: bool = True, is_ws: bool = False):

        super().__init__()
        self.params = params
        self.verify_ssl = verify_ssl
        self.is_ws = is_ws

    @staticmethod
    def get_record_uid(record: KeeperRecord) -> bytes:
        return record.record_uid

    @staticmethod
    def get_key_bytes(record: KeeperRecord) -> bytes:
        return record.record_key

    @property
    def hostname(self) -> str:
        # The host is connect.keepersecurity.com, connect.dev.keepersecurity.com, etc. Append "connect" in front
        # of host used for Commander.
        return f'connect.{self.params.config.get("server")}'

    @property
    def dag_server_url(self) -> str:

        # Allow override of the URL. If not set, get the hostname from the config.
        hostname = os.environ.get("DAG_SERVER_URL", self.hostname)
        if hostname.startswith('ws') or hostname.startswith('http'):
            return hostname

        use_ssl = os.environ.get("DAG_USE_SSL", True)
        if self.is_ws is True:
            prot_pref = 'ws'
        else:
            prot_pref = 'http'
        if use_ssl is True:
            prot_pref += "s"

        return f'{prot_pref}://{hostname}'

    def rest_call_to_router(self, http_method: str, endpoint: str,
                            payload_json: Optional[Union[bytes, str]] = None) -> str:

        transmission_key = utils.generate_aes_key()
        server_public_key = rest_api.SERVER_PUBLIC_KEYS[self.params.rest_context.server_key_id]

        if self.params.rest_context.server_key_id < 7:
            encrypted_transmission_key = crypto.encrypt_rsa(transmission_key, server_public_key)
        else:
            encrypted_transmission_key = crypto.encrypt_ec(transmission_key, server_public_key)
        encrypted_session_token = crypto.encrypt_aes_v2(
            utils.base64_url_decode(self.params.session_token), transmission_key)

        if payload_json is not None and isinstance(payload_json, bytes) is False:
            payload_json = payload_json.encode()

        if endpoint.startswith("/") is False:
            endpoint = "/" + endpoint

        try:
            response = requests.request(
                method=http_method,
                url=self.dag_server_url + endpoint,
                verify=self.verify_ssl,
                headers={
                    'TransmissionKey': bytes_to_base64(encrypted_transmission_key),
                    'Authorization': f'KeeperUser {bytes_to_base64(encrypted_session_token)}'
                },
                data=payload_json
            )
            response.raise_for_status()
            return response.text
        except Exception as ex:
            raise ex
