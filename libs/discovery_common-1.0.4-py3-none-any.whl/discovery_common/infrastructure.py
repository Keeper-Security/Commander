from __future__ import annotations
import logging
from .constants import DIS_INFRA_GRAPH_ID
from .utils import value_to_boolean
from keeper_dag import DAG, EdgeType
from keeper_dag.connection.local import Connection as LocalDag
from keeper_dag.crypto import urlsafe_str_to_bytes
import os
import importlib
from typing import Any, Optional


class Infrastructure:

    """
    Create a graph of the infrastructure.

    The first run will create a full graph since the vertices do not exist.
    Further discovery run will only show vertices that ...
    * do not have vaults records.
    * the data has changed.
    * the ACL has changed.

    """

    KEY_PATH = "infrastructure"
    DELTA_PATH = "delta"
    ADMIN_PATH = "ADMINS"
    USER_PATH = "USERS"

    def __init__(self, record: Any, logger: Optional[Any] = None, history_level: int = 0,
                 debug_level: int = 0, **kwargs):

        if value_to_boolean(os.environ.get("USE_LOCAL_DAG")) is True:
            conn = LocalDag()
        else:
            ksm = kwargs.get("ksm")
            params = kwargs.get("params")
            if ksm is not None:
                from keeper_dag.connection.ksm import Connection
                conn = Connection(config=ksm.storage_config)
            elif params is not None:
                from keeper_dag.connection.commander import Connection
                conn = Connection(params=params)
            else:
                raise ValueError("Must pass 'ksm' for KSK, 'params' for Commander. Found neither.")
        self.conn = conn

        # This will either be a KSM Record, or Commander KeeperRecord
        self.record = record
        self._dag = None
        if logger is None:
            logger = logging.getLogger()
        self.logger = logger
        self.history_level = history_level
        self.debug_level = debug_level

        self.auto_save = False
        self.delta_graph = True
        self.last_sync_point = -1

    @property
    def dag(self) -> DAG:
        if self._dag is None:

            self.logger.debug(f"loading the dag graph {DIS_INFRA_GRAPH_ID}")

            self._dag = DAG(conn=self.conn, record=self.record, graph_id=DIS_INFRA_GRAPH_ID, auto_save=self.auto_save,
                            logger=self.logger, history_level=self.history_level, debug_level=self.debug_level)

            # The full graph needs to be loaded for discovery.
            # The sync point is the end of existing edges.
            # Everything after the sync point is what we are adding here.
            self.last_sync_point = self._dag.load(sync_point=0)

            # Has the infrastructure been initialized?
            # If it has not, we do not want to do a delta graph.
            # We also can use auto save if not a delta graph.
            if self._dag.has_graph is False:
                self.logger.debug("graph does not exist, not using delta graph and auto save is True.")
                self.delta_graph = False
                self.last_sync_point = 0

            self.logger.debug(f"auto save is {self.auto_save}")
            self.logger.debug(f"save as delta is {self.delta_graph}")

        return self._dag

    @property
    def has_discovery_data(self) -> bool:
        return self.dag.has_graph

    @property
    def get_root(self):
        return self.dag.get_root

    @property
    def sync_point(self):
        return self._dag.load(sync_point=0)

    def load(self, sync_point: int = 0):
        return self.dag.load(sync_point=sync_point) or 0

    def save(self, delta_graph: Optional[bool] = None):
        if delta_graph is None:
            delta_graph = self.delta_graph

        self.logger.debug(f"current sync point {self.last_sync_point}")
        if delta_graph is True:
            self.logger.debug("saving delta graph of the infrastructure")
        self._dag.save(delta_graph=delta_graph)

    def to_dot(self, graph_format: str = "svg", show_hex_uid: bool = False,
               show_version: bool = True, show_only_active_vertices: bool = False,
               show_only_active_edges: bool = False, sync_point: int = None, graph_type: str = "dot"):

        try:
            mod = importlib.import_module("graphviz")
        except ImportError:
            raise Exception("Cannot to_dot(), graphviz module is not installed.")

        dot = getattr(mod, "Digraph")(comment=f"DAG for Discovery", format=graph_format)

        config_vertex = self.dag.get_root.has_vertices()[0]
        count = len(config_vertex.has_vertices())

        if graph_type == "dot":
            dot.attr(rankdir='RL')
            rank_sep = 10
            if count > 10:
                rank_sep += int(count * 0.10)
            dot.attr(ranksep=str(rank_sep))
        elif graph_type == "twopi":
            rank_sep = 20
            if count > 20:
                rank_sep += int(count * 0.10)

            dot.attr(layout="twopi")
            dot.attr(ranksep=str(rank_sep))
            dot.attr(ratio="auto")
        else:
            dot.attr(layout=graph_type)
            dot.attr(ranksep=10)

        if sync_point is None:
            sync_point = self.last_sync_point

        self.logger.debug(f"generating infrastructure dot starting at sync point {sync_point}")

        self.dag.load(sync_point=sync_point)

        for v in self.dag.all_vertices:
            if show_only_active_vertices is True and v.active is False:
                continue

            shape = "ellipse"
            fillcolor = "white"
            color = "black"
            if v.active is False:
                fillcolor = "grey"

            record_type = None
            record_uid = None
            name = v.name
            try:
                data = v.content_as_dict
                record_type = data.get("record_type")
                record_uid = data.get("record_uid")
                name = data.get("name")
                item = data.get("item")
                if item is not None:
                    if item.get("managed", False) is True:
                        shape = "box"
                if record_uid is not None:
                    fillcolor = "#AFFFAF"
                if data.get("ignore_object", False) is True:
                    fillcolor = "#DFDFFF"
            except (Exception,):
                pass

            label = f"uid={v.uid}"
            if record_type is not None:
                label += f"\\nrt={record_type}"
            if name is not None and name != v.uid:
                label += f"\\nname={name}"
            if record_uid is not None:
                label += f"\\nruid={record_uid}"
            if show_hex_uid is True:
                label += f"\\nhex={urlsafe_str_to_bytes(v.uid).hex()}"
            if v.uid == self.dag.get_root.uid:
                fillcolor = "gold"
                label += f"\\nsp={sync_point}"

            tooltip = f"ACTIVE={v.active}\\n\\n"
            try:
                content = v.content_as_dict
                for k, val in content.items():
                    if k == "item":
                        continue
                    tooltip += f"{k}={val}\\n"

                item = content.get("item")
                if item is not None:
                    tooltip += f"------------------\\n"
                    for k, val in item.items():
                        tooltip += f"{k}={val}\\n"
            except (Exception,):
                pass

            dot.node(v.uid, label, color=color, fillcolor=fillcolor, style="filled", shape=shape, tooltip=tooltip)

            head_uids = []
            for edge in v.edges:
                if edge.edge_type == EdgeType.DATA:
                    continue
                if edge.head_uid not in head_uids:
                    head_uids.append(edge.head_uid)

            def _render_edge(e):
                color = "grey"
                style = "solid"

                # To reduce the number of edges, only show the active edges
                if e.active is True:
                    color = "black"
                    style = "bold"
                elif show_only_active_edges is True:
                    return

                # If the vertex is not active, gray out the DATA edge
                if e.edge_type == EdgeType.DATA and v.active is False:
                    color = "grey"

                if e.edge_type == EdgeType.DELETION:
                    style = "dotted"

                edgetip = ""
                if e.edge_type == EdgeType.ACL and v.active is True:
                    content = e.content_as_dict
                    for k, val in content.items():
                        edgetip += f"{k}={val}\\n"
                    if content.get("is_admin") is True:
                        color = "red"

                label = DAG.EDGE_LABEL.get(edge.edge_type)
                if label is None:
                    label = "UNK"
                if edge.path is not None and edge.path != "":
                    label += f"\\npath={edge.path}"
                if show_version is True:
                    label += f"\\nv={edge.version}"

                # tail, head (arrow side), label, ...
                dot.edge(v.uid, e.head_uid, label, style=style, fontcolor=color, color=color, tooltip=edgetip)

            for head_uid in head_uids:
                version, edge = v.get_highest_edge_version(head_uid)
                _render_edge(edge)

            data_edge = v.get_data()
            if data_edge is not None:
                _render_edge(data_edge)

        return dot

    def render(self, name: str, **kwargs):

        output_name = os.environ.get("GRAPH_DIR", os.environ.get("HOME", os.environ.get("PROFILENAME", ".")))
        output_name = os.path.join(output_name, name)
        dot = self.to_dot(**kwargs)
        dot.render(output_name)
